package sample;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.*;

public class MainController {



	private MainStore floorsStore = new MainStore();
	/**
	 * FXML input fields
	 */
	//this came from sample fxml (scene builder (all the buttons etc used in the GUI) )
	@FXML
	public TextArea main;
	@FXML
	private TextField noFloor;
	@FXML
	private TextField IDFloor;
	@FXML
	private TextField levelofFloor;
	@FXML
	private TextField levelSecurity;
	@FXML
	private TextField tempofFloor;
	@FXML
	private TextField noAisle;
	@FXML
	private TextField widthofAisle;
	@FXML
	private TextField lengthofAisle;
	@FXML
	private TextField IDofFloor;
	@FXML
	private TextField noShelf;
	@FXML
	private TextField noshelfFloor;
	@FXML
	private TextField noshelfAisle;
	@FXML
	private TextField descriptionofPallet;
	@FXML
	private TextField amountofPallets;
	@FXML
	private TextField mintempofPallet;
	@FXML
	private TextField maxtempofPallet;
	@FXML
	private TextField nooffloorPallet;
	@FXML
	private TextField noofAislePallet;
	@FXML
	private TextField noofshelfPallet;
	@FXML
	private TextField noPallet;
	@FXML
	private TextField removeFloorID;
	@FXML
	private TextField removeAisleID;
	@FXML
	private TextField removeShelfID;
	@FXML
	private TextField removePalletID;
	@FXML
	private TextField goodsSearch;


	/**
	 * This method adds Floor
	 *
	 * @throws IOException
	 */
	/**
	 * This will add all aspects of the Floor, ID, level, security level and the floor temperature
	 * @param actionEvent
	 * @throws IOException
	 */
	public void handleAddFloor(ActionEvent actionEvent) throws Exception {
		System.out.println("Floor");
		//validation
		//try to do something(tasks) if exception is thrown then we catch it and display it in our text box.
		try{
			//reading in data from text boxes and parsing(turn a string a different variable e.g int,double
			// those that require to be changed into a different variable
			int number = Integer.parseInt(this.noFloor.getText());//can throw number format exception if a letter is passed instead of a number
			int id = Integer.parseInt(this.IDFloor.getText());//can throw number format exception if a letter is passed instead of a number
			int level = Integer.parseInt(this.levelofFloor.getText());//can throw number format exception if a letter is passed instead of a number
			String security = this.levelSecurity.getText();
			double temperature = Double.parseDouble(this.tempofFloor.getText());//can throw number format exception if a letter is passed instead of a number

           //creating a new floor with the details that were read in
			Floor floor = new Floor(number, id, level, security, temperature);//can throw exception (this will happen if security is invalid)
			//adding a floor to floorStore
			floorsStore.addFloor(floor);

            //display details of the floor that has just been added
			main.setText(floorsStore.listFloors());
			saveData();
			//catch the number format exception which will occur if a letter has been inputted instead of a number
		} catch (NumberFormatException e){
			main.setText("Numeric value required");
			//catch all exceptions
		} catch(Exception e){
			main.setText(e.getMessage());//this will display the message associated with the exception thrown (this will happen with the floor security)
		}


	}

	/**
	 * This method adds Aisle
	 *
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */

	/**
	 * This method will add an Aisle, this will include the aisle number, width and length
	 * @param actionEvent
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void handleAddAisle(ActionEvent actionEvent) throws IOException, ClassNotFoundException {
		System.out.println("Aisle");

		try {
			//reading in data from text boxes and parsing(turn a string a different variable e.g int,double
			// those that require to be changed into a different variable

			String identifier = this.noAisle.getText();
			int width = Integer.parseInt(this.widthofAisle.getText());
			int length = Integer.parseInt(this.lengthofAisle.getText());
			int floorNumber = Integer.parseInt(this.IDofFloor.getText());
			//boolean made to tell if the aisle has been successfully added
			boolean aisleAdded = false;
			//creating new aisle
			Aisle aisle = new Aisle(identifier, width, length);
			//using an enhanced for loop to get through all the floors in the floorStore
			for(Floor f : floorsStore.getFloors()){
				//checking if the inputted floor number matches any currently stored in the system
				if(f.getfNum() == floorNumber){
					//if matches is found, aisle added to our floor
					f.getaList().add(aisle);
					//changing the aisle to true because an aisle has just been added
					aisleAdded = true;
				}
			}
			//if aisle added is true, let the user know by displaying an aisle added message otherwise display aisle not added
			if (aisleAdded == true){
				main.setText("Aisle Added");
			}else {
				main.setText("Aisle not added");
			}
		} catch (NumberFormatException e){
			main.setText("Numeric value required");
			//catch all exceptions
		} catch (Exception e) {
			main.setText("Incorrect Identifier format, This should start with a letter and a number");
		}




		saveData();
	}
// for loop for aisle number and then add the aisle once you find the aisle with that number, same for the others, validation,
	/**
	 * This method adds Shelf
	 */

	/**
	 * This method will add a shelf this includes the shelf number, the number of shelves in a floor and the number of shelves in an aisle
	 * @param actionEvent
	 * @throws IOException
	 */
	public void handleAddShelf(ActionEvent actionEvent) throws IOException {
		System.out.println("Shelf");
		//reading in data from text boxes and parsing(turn a string a different variable e.g int,double
		// those that require to be changed into a different variable
		int number = Integer.parseInt(this.noShelf.getText());
		int floorNumber = Integer.parseInt(this.noshelfFloor.getText());
		String aisleID = this.noshelfAisle.getText();
		//track if the shelf has been added
		boolean shelfAccepted = false;

		Shelf shelf = new Shelf(number);
		//Loop through all floor to find matching floor number
		for (Floor f : floorsStore.getFloors()) {
			//== is used as floor is an int, which is a primative type
			if (f.getfNum() == floorNumber) {
				//Loop through all aisles to find matching aisle ID
				for (Aisle a : f.getaList()) {
					//.equals methods is used for Strings (and other objects)
					if (a.getIdentifier().equals(aisleID)) {
						//adding shelf to correct aisle
						a.getShelfArray().add(shelf);
						// shelf accepted is true
						shelfAccepted = true;

					}
				}
			}

		}
		if (shelfAccepted == true) {
			//displaying the message to the user that the shelf was added
			main.setText("Shelf Added");

		} else {
			//displaying the message to the user that the shelf was not added
			main.setText("shelf not added");
		}
		saveData();
	}
	/**
	 * Add Pallet
	 * @param actionEvent
	 * @throws IOException
	 */

	/**
	 * this method will add a pallet, this includes the description,amount,
	 * min-temperature,max-temperature,
	 * number of each floor containing the pallets,
	 * number of the aisle containing the pallets,
	 * number of shelves containing the pallets
	 * and the ID for the pallets that's being removed
	 *
	 * @param actionEvent
	 * @throws IOException
	 */
	public void handleAddPallet(ActionEvent actionEvent) throws IOException {

		//reading in data from text boxes and parsing(turn a string a different variable e.g int,double
		// those that require to be changed into a different variable
		String description = this.descriptionofPallet.getText();
		int quantity = Integer.parseInt(this.amountofPallets.getText());
		double minTemperature = Double.parseDouble(this.mintempofPallet.getText());
		double maxTemperature = Double.parseDouble(this.maxtempofPallet.getText());
		int floorNumber = Integer.parseInt(this.nooffloorPallet.getText());
		String aisleID = this.noofAislePallet.getText();
		int shelfNumber = Integer.parseInt(this.noofshelfPallet.getText());
		int palledID = Integer.parseInt(this.noPallet.getText());
		//we make it false because it hasn't been added yet
		boolean palletAdded = false;
		//creating a new instance of pallet
		Pallet pallet = new Pallet(description, quantity, minTemperature, maxTemperature, palledID);

		for(Floor f : floorsStore.getFloors()){
			//loop until matching floor number is found
			if (f.getfNum() == floorNumber){
				//Loop through all aisles to find matching aisle ID
				for (Aisle a : f.getaList()){
					if(a.getIdentifier().equals(aisleID) ){
						//loop through all the shelf's until we find the matching shelf, once we find the matching shelf we add the pallet to that.
						for (Shelf s : a.getShelfArray()){
							if(s.getsNum() == shelfNumber){
								s.getListForPallet().add(pallet);
								palletAdded = true;
							}
						}
					}
				}
			}

		}
      if (palletAdded == true){
//displaying the message to the user that the shelf was added
	main.setText("Pallet Added");

       }else {
		  //displaying the message to the user that the shelf was not added
	main.setText("Pallet not added");
      }



		saveData();
	}

	/**
	 * Search
	 * @param actionEvent
	 */
	/**
	 * This method will search for all goods
	 * @param actionEvent
	 * nested for loop
	 */
	public void handleSearchForGoods(ActionEvent actionEvent) {
		//reading in the string to be searched and making this lowercase otherwise it wouldn't find it
		String search = this.goodsSearch.getText().toLowerCase();

		//track if anything was found
		boolean searchFound = false;

//looping through all floors
		for (Floor floor : floorsStore.getFloors()) {
			//looping through all aisles
			for (Aisle aisle : floor.getaList()) {
				//looping through all shelves
				for (Shelf shelf : aisle.getShelfArray()) {
					//looping through all pallets
					for (Pallet pallet : shelf.getListForPallet()) {
						//checking the pallet is not null
						if (pallet != null) {
							//checking if the current pallet description contains the search word
							//making the description lowercase so it can be found in the contains search
							if (pallet.getDescription().toLowerCase().contains(search)) {
								main.setText("Found: \n");
								searchFound = true;
								main.appendText(pallet.toString() + "\n");
							}
						}
					}
				}
			}
		}
		//displaying a message if nothing is found
		if (searchFound == false ){
			main.setText("goods not found");
		}
	}



	/**
	 * show floors
	 * @param actionEvent
	 */
	public void handleShowFloors(ActionEvent actionEvent) {//calls list of floors from the mainStore class
		main.setText(floorsStore.listFloors());
	}


	public void handleShowAll() {//loops through all the details and displaying the details
		//clearing the main text box
		main.setText("");
		//creating an int to track the number of floors
		int floorCounter = 1;
		for (Floor floor : floorsStore.getFloors()) {//Floor is calling the class (House blueprint) , floor is just every single different type (fairy liquid sizes) floorStore stores information from floor, aisle, shelf pallet
			main.appendText(String.valueOf(floorCounter) + ": ");//just the printed out number of the floor
			main.appendText(floor.toString() + "\n");//prints toString and then brings you to a new line after
			floorCounter++;//adds 1 and then goes back through the loop until you're out of numbers
			int aisleCounter = 1;
			for (Aisle aisle : floor.getaList()) {
				main.appendText(" ");
				main.appendText(String.valueOf(aisleCounter) + ": ");//just the printed out number of the aisle
				main.appendText(aisle.toString() + "\n");//prints toString and then brings you to a new line after
				aisleCounter++;//adds 1 and then goes back through the loop until you're out of numbers
				int shelfCounter = 1;
				for (Shelf shelf : aisle.getShelfArray()) {
					main.appendText("  ");
					main.appendText(String.valueOf(shelfCounter) + ": ");//just the printed out number of the shelf
					main.appendText(shelf.toString() + "\n");//prints toString and then brings you to a new line after
					shelfCounter++;//adds 1 and then goes back through the loop until you're out of numbers
					int palletCounter = 1;
					for (Pallet pallet : shelf.getListForPallet()) {
						main.appendText("   ");
						main.appendText(String.valueOf(palletCounter) + ": ");//just the printed out number of the pallet
						main.appendText(pallet.toString() + "\n");//prints toString and then brings you to a new line after
						palletCounter++;//this method is the same as listFloors from mainStore but it's just repeated for pallets, shellfs, aisles and floors
					}
				}
			}
		}
	}


	/**
	 * This method saves the data
	 *
	 * @throws IOException
	 */
	public void saveData() throws IOException {
		//creating xstream and writing current floorStore to xml file
		XStream xstream = new XStream(new DomDriver());
		ObjectOutputStream out = xstream.createObjectOutputStream
				(new FileWriter("floorStore.xml"));
		out.writeObject(floorsStore);
		out.close();
	}

	/**
	 * This method loads the data
	 *
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void loadData() throws IOException, ClassNotFoundException {
		//reading in previous floorStore  from xml file
		XStream xstream = new XStream(new DomDriver());
		ObjectInputStream is = xstream.createObjectInputStream
				(new FileReader("floorStore.xml"));
		floorsStore = (MainStore) is.readObject();
		is.close();
	}


	public void handleRemovePallet(ActionEvent actionEvent) throws IOException {

		//reading in data from text boxes and parsing(turn a string a different variable e.g int,double
		// those that require to be changed into a different variable

		int floorNumber = Integer.parseInt(this.removeFloorID.getText());
		String aisleID = this.removeAisleID.getText();
		int shelfNumber = Integer.parseInt(this.removeShelfID.getText());
		boolean removeSuccess = false;
		int palledID = Integer.parseInt(this.removePalletID.getText());

		for(Floor f : floorsStore.getFloors()){
			//loop until matching floor number is found
			if (f.getfNum() == floorNumber){
				//Loop through all aisles to find matching aisle ID
				for (Aisle a : f.getaList()){
					if(a.getIdentifier().equals(aisleID) ){
						//loop through all the shelf's until we find the matching shelf, once we find the matching shelf we add the pallet to that.
						for (Shelf s : a.getShelfArray()){
							if(s.getsNum() == shelfNumber){
								//looping through all pallets on that shelf
								for (Pallet p : s.getListForPallet()){
									if(p.getId() == palledID){
										//if pallet is found, removing it from the list
										s.getListForPallet().remove(p);
										removeSuccess = true;
										//breaking out of loop as the operation is complete
										break;
									}


								}
							}
						}
					}
				}
			}

		}
		if (removeSuccess == true){
			//telling the user if pallet has been added successfully
			main.setText("Pallet removed");
		}else{
			//telling the user if pallet has not been added
			main.setText("Pallet not found");
		}




		saveData();
	}

	}

