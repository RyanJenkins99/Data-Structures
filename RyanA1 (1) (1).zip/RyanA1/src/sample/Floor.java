package sample;

import java.util.ArrayList;

public class Floor {
	//declare class properties

	private int fNum;
	private int id;
	private int fLvl;
	private String security;
	private double fTemp;

	private ArrayList<Aisle> aList;



	/**
	 * Constructor
	 * @param fNum
	 * @param id
	 * @param fLvl
	 * @param security
	 * @param fTemp
	 */
	public Floor(int fNum, int id, int fLvl, String security, double fTemp) throws Exception {
		//initialize class properties with passed values
		this.fNum = fNum;
		this.id = id;
		this.fLvl = fLvl;
		//verify security value is valid or throw exception
		if(security.equals("High") || security.equals("Low") || security.equals("Medium")){
			this.security = security;
		} else {
			throw new Exception("Invalid Security Level");
		}
		this.fTemp = fTemp;
		//initialize the arraylist to hold all aisles on the floor
		this.aList = new ArrayList<Aisle>();
	}

	/**
	 * Getters and setters
	 */
	public int getfNum() {
		return fNum;
	}

	public void setfNum(int fNum) {
		this.fNum = fNum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getfLvl() {
		return fLvl;
	}

	public void setfLvl(int fLvl) {
		this.fLvl = fLvl;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public double getfTemp() {
		return fTemp;
	}

	public void setfTemp(double fTemp) {
		this.fTemp = fTemp;
	}

	public ArrayList<Aisle> getaList() {
		return aList;
	}

	public void setaList(ArrayList<Aisle> aList) {
		this.aList = aList;
	}

	/**
	 * toString for Floor
	 * @return floor params
	 */
	@Override
	public String toString() {
		return "Floor{" +
				"floorNumber=" + fNum +
				", identifier=" + id +
				", floorLevel=" + fLvl +
				", security='" + security + '\'' +
				", floorTemperature=" + fTemp +
				", aisleArrayList=" + aList +
				'}';
	}
}
