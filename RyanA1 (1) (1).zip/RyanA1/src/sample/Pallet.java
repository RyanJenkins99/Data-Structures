package sample;

public class Pallet {//lays out blueprint of what a pallet is
	//declare class properties
	private String description;
	private int quantity;
	private double minTemp;
	private double maxTemp;
	private int id;


	/**
	 * Constructor for Pallet
	 * @param description
	 * @param quantity
	 * @param minTemp
	 * @param maxTemp
	 */
	public Pallet(String description, int quantity, double minTemp, double maxTemp, int id) {
		//initializing class properties
		//this refers to class properties at the top
		this.description = description;//this.description in this line is what the user edits, it then passes through the line above and then back to the public class at the top
		this.quantity = quantity;
		this.minTemp = minTemp;
		this.maxTemp = maxTemp;
		this.id = id;
	}

	/**
	 * Getters and setters
	 */
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getMinTemp() {
		return minTemp;
	}

	public void setMinTemp(double minTemp) {
		this.minTemp = minTemp;
	}

	public double getMaxTemp() {
		return maxTemp;
	}

	public void setMaxTemp(double maxTemp) {
		this.maxTemp = maxTemp;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * toString
	 * @return Pallet params
	 */
	@Override
	public String toString() {
		return "Pallet{" +
				"description='" + description + '\'' +
				", quantity=" + quantity +
				", minTemperature=" + minTemp +
				", maxTemperature=" + maxTemp +
				", id=" + id +
				'}';//toString represents the object of the class
	}
}
