package sample;

import java.util.ArrayList;

public class Shelf {
	//declare class properties
	private int sNum;
	private ArrayList<Pallet> listForPallet;//global fields, the whole class can access these things, (Array list is a list of pallets)



	/**
	 * Constructor
	 * @param shelfNumber
	 */
	public Shelf(int shelfNumber) {
		this.sNum = shelfNumber;//(this) is used for local variables within a method
		this.listForPallet = new ArrayList<Pallet>();//initializing arraylist to hold all pallets on the shelf
	}

	/**
	 * Getters and setters(pulls the information and stores it)
	 */
	public int getsNum() {
		return sNum;
	}

	public void setsNum(int sNum) {
		this.sNum = sNum;
	}

	public ArrayList<Pallet> getListForPallet() {
		return listForPallet;
	}

	public void setListForPallet(ArrayList<Pallet> listForPallet) {
		this.listForPallet = listForPallet;
	}

	/**
	 * toString(tells you whats in this class)
	 * @return Shelf params
	 */
	@Override
	public String toString() {
		return "Shelf{" +
				"shelfNumber=" + sNum +
				", palletList=" + listForPallet +
				'}'; // toString: the purple pulls information from getter , this makes sure you don't have to put in a certain value, it does it for you
	}
}
