package sample;

import javafx.fxml.FXML;

import java.util.ArrayList;

public class MainStore {
	/**
	 * This method creates Arraylist of type floor
	 */
	@FXML
	private ArrayList<Floor> floors = new ArrayList<Floor>();//An array list to store them in the main store


	public void addFloor(Floor floor){
		floors.add(floor);
	}//method for adding a floor to the floors arraylist

	/**
	 * This method lists all floors
	 * @return floor
	 */
	public String listFloors(){
		String returnString = "";//create an empty string to hold returnString
		int i = 0; // the 1st floor will be floor 0
//loop through all the floors and add the floor number and each floor toString
		for(Floor floor : floors){
			returnString += "\n"//new line
					+ i
					+ "= "
					+ floor.toString();//it's calling the toString from the floor class
			i++;
		}

		return returnString;
	}

	/**
	 * Getters and setters
	 */
	public ArrayList<Floor> getFloors() {
		return floors;
	}

	public void setFloors(ArrayList<Floor> floors) {
		this.floors = floors;
	}
}
