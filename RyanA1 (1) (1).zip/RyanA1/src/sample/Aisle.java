package sample;

import java.util.ArrayList;

public class Aisle {
//declare class properties
	private String identifier;
	private int x;
	private int y;
	private ArrayList<Shelf> shelfArray;


	/**
	 * Constructor
	 * @param identifier
	 * @param x
	 * @param y
	 */
	public Aisle(String identifier, int x, int y) throws Exception {
		//taking first 2 character from the identifier
		char letter = identifier.charAt(0);//get us the character at 0 and store it to the char letter
		char number = identifier.charAt(1);//get us the character at 1 and store it to the char number
		//verify that the first character is a letter and second is a number
		if (Character.isLetter(letter) && Character.isDigit(number)){//verifies that 1st is a letter and second is a number
			this.identifier = identifier;
		}
		//throwing an exception if this isn't the case
		else {
			throw new Exception("incorrect format for identifier");
		}

		this.x = x;
		this.y = y;
		//initializing arraylist to hold all shelves on the aisle
		this.shelfArray = new ArrayList<Shelf>();
	}

	/**
	 * Getters and setters
	 */
	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public ArrayList<Shelf> getShelfArray() {
		return shelfArray;
	}

	public void setShelfArray(ArrayList<Shelf> shelfArray) {
		this.shelfArray = shelfArray;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	/**
	 * toString
	 * @return Aisle params
	 */
	@Override
	public String toString() {
		return "Aisle{" +
				"aisleNumber='" + identifier + '\'' +
				", shelfArrayList=" + shelfArray +
				'}';
	}
}
